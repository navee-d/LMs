import React from 'react';

const Pagination = ({ currentPage, totalPages }) => {
  return (
    <div className="pagination">
      <button className="pagination-button prev" disabled={currentPage === 1}>
        Previous
      </button>
      
      <div className="pagination-numbers">
        {currentPage > 1 && <span className="page-number">{currentPage - 1}</span>}
        <span className="page-number active">{currentPage}</span>
        {currentPage < totalPages && <span className="page-number">{currentPage + 1}</span>}
      </div>
      
      <button className="pagination-button next" disabled={currentPage === totalPages}>
        Next
      </button>
    </div>
  );
};

export default Pagination;