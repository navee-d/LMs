import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import '../styles/Sidebar.css'
const Sidebar = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  const menuItems = [
    { name: 'Dashboard', path: '/' },
    { name: 'Lecturers', path: '/lecturers' },
    { name: 'Schedule', path: '/schedule' },
    { name: 'Attendance', path: '/attendance' },
    { name: 'Payments', path: '/payments' },
    { name: 'Login', path: '/logout' },
  ];

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <h2>Visiting Lecture Management System</h2>
      </div>
      
      <div className="admin-profile">
        <div className="avatar">
          <div className="avatar-circle"></div>
        </div>
        <span className="admin-label">Admin</span>
      </div>
      
      <nav className="sidebar-menu">
        <ul>
          {menuItems.map((item) => (
            <li key={item.name} className={currentPath === item.path ? 'active' : ''}>
              <Link to={item.path}>{item.name}</Link>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="sidebar-footer">
        <p>© 2025 VLM System | Privacy Policy | Terms of Service</p>
      </div>
    </div>
  );
};

export default Sidebar;