import React from 'react';
import './Button.css';

const Button = ({ children, variant = 'primary', onClick, disabled }) => {
  return (
    <button 
      className={`custom-button ${variant}`} 
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
};

export default Button;