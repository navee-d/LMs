import React from 'react';
import Sidebar from '../components/Sidebar';
import '../styles/Layout.css'; // Import Layout styles

const Layout = ({ children }) => {
  return (
    <div className="layout-container">
      <Sidebar />
      <div className="main-content">{children}</div>
    </div>
  );
};

export default Layout;
