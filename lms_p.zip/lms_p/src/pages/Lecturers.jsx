import React from 'react';
import StatusBadge from '../components/StatusBadge';
import Pagination from '../components/Pagination';

const Lecturers = () => {
  // Sample data
  const lecturers = [
    { id: 1, name: 'A. Kumar', expertise: 'Data Science', contact: 'example@mail.com', status: 'Active' },
    { id: 2, name: 'B. Johnson', expertise: 'Web Development', contact: 'example2@mail.com', status: 'Pending' },
    // Add more sample data as needed
  ];

  return (
    <div className="page-container">
      <div className="page-header">
        <h1 className="page-title">Lecture Management</h1>
        <button className="add-button">Add Lecturer</button>
      </div>
      
      <div className="filter-section">
        <button className="filter-button active">All</button>
        <button className="filter-button">Active</button>
        <button className="filter-button">Pending</button>
        <button className="filter-button">Inactive</button>
      </div>
      
      <div className="data-container">
        <table className="data-table">
          <thead>
            <tr>
              <th><input type="checkbox" /></th>
              <th>Name</th>
              <th>Expertise</th>
              <th>Contact</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {lecturers.map(lecturer => (
              <tr key={lecturer.id}>
                <td><input type="checkbox" /></td>
                <td>{lecturer.name}</td>
                <td>{lecturer.expertise}</td>
                <td>{lecturer.contact}</td>
                <td>
                  <StatusBadge status={lecturer.status} />
                </td>
                <td className="actions-cell">
                  <button className="edit-button">Edit</button>
                  <button className="delete-button">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <Pagination currentPage={1} totalPages={3} />
    </div>
  );
};

export default Lecturers;