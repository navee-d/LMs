import React from 'react';
import '../styles/Dashboard.css'

const Dashboard = () => {
  return (
    <div className="page-container">
      <h1 className="page-title">Dashboard</h1>
      
      <div className="stats-cards">
        <div className="stat-card upcoming">
          <h3>Upcoming Lectures</h3>
          <div className="stat-value">12</div>
        </div>
        
        <div className="stat-card active">
          <h3>Active Lectures</h3>
          <div className="stat-value">24</div>
        </div>
        
        <div className="stat-card pending">
          <h3>Pending Payments</h3>
          <div className="stat-value">8</div>
        </div>
      </div>
      
      <div className="schedule-section">
        <h3>Upcoming Schedule</h3>
        <table className="data-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Time</th>
              <th>Lecturer</th>
              <th>Topic</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <div className="bottom-sections">
        <div className="applications-section">
          <h3>Recent Applications</h3>
          <div className="applications-placeholder"></div>
        </div>
        
        <div className="payment-section">
          <h3>Payment Summary</h3>
          <div className="payment-list">
            <div className="payment-item"></div>
            <div className="payment-item"></div>
            <div className="payment-item"></div>
            <div className="payment-item"></div>
          </div>
          <button className="generate-report">Generate Report</button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;