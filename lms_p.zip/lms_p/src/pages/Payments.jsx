import React from 'react';
import Pagination from '../components/Pagination';
import StatusBadge from '../components/StatusBadge';

const Payments = () => {
  // Sample payment data
  const payments = [
    { id: 'VL-01-001', lecturer: 'Robert Wilson', month: 'March 2025', amount: '$700.00', status: 'Pending' },
    // Add more sample payments
  ];

  return (
    <div className="page-container">
      <div className="page-header">
        <h1 className="page-title">Payment Management</h1>
        <button className="add-button">Filter</button>
      </div>
      
      <div className="filter-row">
        <div className="month-filter">
          <label>Month:</label>
          <select>
            <option value="">All Months</option>
            <option value="March 2025">March 2025</option>
            <option value="April 2025">April 2025</option>
          </select>
        </div>
        <div className="status-filter">
          <label>Status:</label>
          <select>
            <option value="">All Status</option>
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Paid">Paid</option>
          </select>
        </div>
      </div>
      
      <div className="action-buttons">
        <button className="action-button new">New Attendance</button>
        <button className="action-button batch">Batch Approval</button>
        <button className="action-button export">Export Report</button>
      </div>
      
      <div className="data-container">
        <table className="data-table">
          <thead>
            <tr>
              <th><input type="checkbox" /></th>
              <th>ID</th>
              <th>Lecturer Name</th>
              <th>Month</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {payments.map(payment => (
              <tr key={payment.id}>
                <td><input type="checkbox" /></td>
                <td>{payment.id}</td>
                <td>{payment.lecturer}</td>
                <td>{payment.month}</td>
                <td>{payment.amount}</td>
                <td>
                  <StatusBadge status={payment.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <Pagination currentPage={1} totalPages={5} />
    </div>
  );
};

export default Payments;