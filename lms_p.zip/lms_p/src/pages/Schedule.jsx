import React, { useState } from 'react';

const Schedule = () => {
  const [currentMonth, setCurrentMonth] = useState('March 2025');
  
  // Days of the week
  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  
  // Generate schedule grid (empty for now)
  const generateScheduleGrid = () => {
    return Array(7).fill(null).map((_, rowIndex) => (
      <div key={rowIndex} className="schedule-row">
        {Array(7).fill(null).map((_, colIndex) => (
          <div key={colIndex} className="schedule-cell">
            {/* Schedule content would go here */}
          </div>
        ))}
      </div>
    ));
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1 className="page-title">Schedule Management</h1>
        <button className="add-button">Add Schedule</button>
      </div>
      
      <div className="schedule-filters">
        <div className="month-selector">
          <button className="active">Week</button>
          <button>Day</button>
          
          <div className="month-picker">
            <span>Month: </span>
            <select value={currentMonth} onChange={(e) => setCurrentMonth(e.target.value)}>
              <option value="March 2025">March 2025</option>
              <option value="April 2025">April 2025</option>
              <option value="May 2025">May 2025</option>
            </select>
          </div>
        </div>
      </div>
      
      <div className="calendar-container">
        <div className="calendar-header">
          {daysOfWeek.map(day => (
            <div key={day} className="day-header">{day}</div>
          ))}
        </div>
        
        <div className="calendar-body">
          {generateScheduleGrid()}
        </div>
      </div>
      
      <div className="legend">
        <div className="legend-item">
          <span className="color-box confirmed"></span>
          <span>Confirmed</span>
        </div>
        <div className="legend-item">
          <span className="color-box pending"></span>
          <span>Pending</span>
        </div>
        <div className="legend-item">
          <span className="color-box cancelled"></span>
          <span>Cancelled</span>
        </div>
      </div>
      
      <div className="page-footer">
        <p>© 2025 VLM System | Privacy Policy | Terms of Service</p>
      </div>
    </div>
  );
};

export default Schedule;