import React, { useState } from 'react';

const Login = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    // In a real app, you would validate credentials
    onLogin();
  };

  return (
    <div className="login-container">
      <div className="login-sidebar">
        <h2>Visiting Lecture Management System</h2>
        
        <div className="admin-profile">
          <div className="avatar">
            <div className="avatar-circle"></div>
          </div>
          <span className="admin-label">Admin</span>
        </div>
        
        <nav className="sidebar-menu">
          <ul>
            <li>Dashboard</li>
            <li>Lecturers</li>
            <li>Schedule</li>
            <li>Attendance</li>
            <li>Payments</li>
            <li className="active">Login</li>
          </ul>
        </nav>
      </div>
      
      <div className="login-content">
        <div className="login-form-container">
          <h1>Login</h1>
          <p>Sign in to your account</p>
          
          <form onSubmit={handleSubmit} className="login-form">
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input 
                type="email" 
                id="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input 
                type="password" 
                id="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            
            <div className="form-options">
              <div className="remember-me">
                <input 
                  type="checkbox" 
                  id="remember" 
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                />
                <label htmlFor="remember">Remember me</label>
              </div>
              <a href="#forgot" className="forgot-link">Forgot Password?</a>
            </div>
            
            <button type="submit" className="sign-in-button">Sign In</button>
          </form>
        </div>
        
        <div className="login-footer">
          <p>© 2025 VLM System | Privacy Policy | Terms of Service</p>
        </div>
      </div>
    </div>
  );
};

export default Login;