import React from 'react';
import Pagination from '../components/Pagination';

const Attendance = () => {
  return (
    <div className="page-container">
      <div className="page-header">
        <h1 className="page-title">Attendance Management</h1>
        <button className="add-button">Export</button>
      </div>
      
      <div className="filter-row">
        <div className="date-filter">
          <label>Date:</label>
          <input type="date" />
        </div>
        <div className="lecturer-filter">
          <label>Lecturer:</label>
          <select>
            <option value="">All Lecturers</option>
            {/* Add lecturer options here */}
          </select>
        </div>
      </div>
      
      <div className="action-buttons">
        <button className="action-button new">New Attendance</button>
      </div>
      
      <div className="data-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Lecturer</th>
              <th>Time In</th>
              <th>Time Out</th>
              <th>Students</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {/* Sample empty rows */}
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td>
                <button className="edit-button">Edit</button>
              </td>
            </tr>
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td>
                <button className="edit-button">Edit</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <Pagination currentPage={1} totalPages={5} />
    </div>
  );
};

export default Attendance;